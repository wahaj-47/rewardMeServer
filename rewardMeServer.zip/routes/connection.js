var development = {
	host: "localhost",
	user: "root@",
	password: "",
	database: "rewardme"
};

var production = {
	host: "localhost",
	user: "merccvhq",
	password: "M6Vm2RYJr3S1",
	database: "merccvhq_rewardme"
};

module.exports = { development, production };
